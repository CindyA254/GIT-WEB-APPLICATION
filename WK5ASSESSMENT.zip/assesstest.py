mathematics = input("Enter mathematics: ")
English = input("Enter English: ")
grade1 = float(mathematics)
grade2 = float(English)
if grade1 >= 30 or grade2 >= 30:
    print("The student has passed the exam")
    print(grade1)
    print(grade2)
if grade1 >= 30 or grade2 >= 30:
    print("The student has failed the exam")
    print(grade1)
    print(grade2)
else:()

